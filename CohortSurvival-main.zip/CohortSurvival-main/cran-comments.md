## R CMD check results

This is a new release.
